package exercicio2;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidacaoVerdadeiroFalso {
	@Test
	public void validacaoVerdadeiro_Sucesso() {
		boolean campoEsperado = true;
		assertTrue(campoEsperado);
	}

	@Test
	public void validacaoVerdadeiro_Falha() {
		boolean campoEsperado = true;
		assertFalse("Campo nao encontrado",campoEsperado);
	}
}
