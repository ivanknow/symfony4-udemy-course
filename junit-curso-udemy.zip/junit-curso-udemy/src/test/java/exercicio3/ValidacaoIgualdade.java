package exercicio3;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ValidacaoIgualdade {
	@Test
	public void ValidacaoIguldade_Sucesso() {
		String var1 = "SIM";
		assertEquals(var1, "SIM");
	}
	@Test
	public void ValidacaoIguldade_Falha() {
		String var1 = "NAO";
		assertEquals(var1, "SIM");
	}
	

}
