package exercicio1;

import org.junit.Test;

public class MeuPrimeiroTest {
	@Test
	public void test1() {
		System.out.println("Teste 1 executado");
	}
	@Test
	public void test2() {
		System.out.println("Teste 2 executado");
	}
	
	public void naoTest1() {
		System.out.println("metodo nao executado");
	}
}
